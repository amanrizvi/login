dbPassword = 'mongodb+srv://aman0501:amanrizvi1@cluster0.fuhiw.mongodb.net/<dbname>?retryWrites=true&w=majority';
module.exports = {
    mongoURI: dbPassword
};
